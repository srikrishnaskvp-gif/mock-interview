# InterviewOS — Minimal Full-Stack Source

This ZIP contains only the essential source code and setup files. It excludes virtual environments, `node_modules`, generated databases, caches, and build output.

## Requirements
- Python 3.11+ (newer versions may need package compatibility checks)
- Node.js and npm
- Ollama with `qwen2.5:3b` pulled for local AI question generation/evaluation

## Start the backend
From this folder, in Terminal 1:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --reload
```

Backend API docs: http://127.0.0.1:8000/docs

## Start local AI
In another terminal, ensure Ollama is running and the model is available:

```powershell
ollama pull qwen2.5:3b
```

## Start the frontend
In Terminal 2:

```powershell
cd frontend
npm install
npm run dev
```

Open the Vite address shown in the terminal (usually http://localhost:5173).

## Features in this minimal build
- React dashboard and navigation
- Interview setup and generated questions
- Text answer submission and AI evaluation
- Results/feedback screen
- Resume text analysis
- Interview history endpoint/UI
- SQLite-backed interview/question/answer records
- Camera-frame analysis endpoint
- Optional local Faster-Whisper transcription endpoint

## Notes
- The transcription path depends on a compatible Faster-Whisper/PyAV installation and should be tested on the target machine.
- Resume analysis accepts pasted text; PDF/DOCX extraction is not included here.
- Camera analysis reports approximate visual quality signals only. These are not proof of cheating or reliable measures of confidence.

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.db import init_db
from app.routers import health, interviews, ai, camera

app = FastAPI(title="AI Interview Preparation API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])
app.include_router(health.router)
app.include_router(interviews.router, prefix="/api")
app.include_router(ai.router, prefix="/api")
app.include_router(camera.router, prefix="/api")

@app.on_event("startup")
def startup():
    init_db()

@app.get("/")
def root():
    return {"name": "AI Interview Preparation API", "status": "running", "docs": "/docs"}

"""Local transcription using Faster-Whisper; model loads only when first needed."""
import asyncio
import os
import tempfile

_model = None

def _transcribe_file(filename, content):
    global _model
    from faster_whisper import WhisperModel
    if _model is None:
        _model = WhisperModel("base", device="cpu", compute_type="int8")
    suffix = os.path.splitext(filename)[1] or ".wav"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as temp:
        temp.write(content)
        path = temp.name
    try:
        segments, _info = _model.transcribe(path)
        return " ".join(segment.text.strip() for segment in segments).strip()
    finally:
        try:
            os.remove(path)
        except OSError:
            pass

async def transcribe_audio(filename, content):
    return await asyncio.to_thread(_transcribe_file, filename, content)

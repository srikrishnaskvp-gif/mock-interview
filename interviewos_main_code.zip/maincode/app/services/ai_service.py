import json
import httpx

OLLAMA_URL = "http://localhost:11434/api/chat"
OLLAMA_MODEL = "qwen2.5:3b"

async def chat(system_prompt: str, user_prompt: str, json_mode: bool = False) -> str:
    payload = {
        "model": OLLAMA_MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "stream": False,
        "options": {"temperature": 0.2},
    }
    if json_mode:
        payload["format"] = "json"
    async with httpx.AsyncClient(timeout=120) as client:
        response = await client.post(OLLAMA_URL, json=payload)
        response.raise_for_status()
        return response.json()["message"]["content"]

def fallback_questions(role, kind, count):
    banks = {
        "technical": [f"What technical skills are important for a {role}, and how have you used them?", "Describe a technical problem you solved.", "How do you debug an issue that is difficult to reproduce?", "Explain a project and your design decisions.", "How would you test a solution before release?", "How do you learn an unfamiliar technology?"],
        "hr": ["Tell me about yourself.", "Why are you interested in this role?", "Describe a challenge and how you handled it.", "What skill are you improving?", "Describe a time you worked in a team.", "What would you like to learn in this role?"],
        "general": [f"Tell me about yourself and your interest in becoming a {role}.", "Describe a project or achievement you are proud of.", "How do you learn an unfamiliar task?", "Describe a problem you solved systematically.", "How do you prioritize competing tasks?", "What questions would you ask an interviewer?"],
    }
    return banks.get(kind, banks["general"])[:count]

async def generate_questions(role, kind, difficulty, count):
    prompt = f'Generate exactly {count} {difficulty}-level {kind} interview questions for a {role}. Return JSON: {{"questions": ["question 1"]}}.'
    try:
        result = json.loads(await chat("You are a professional interview coach. Return valid JSON only.", prompt, True))
        questions = [str(q).strip() for q in result.get("questions", []) if str(q).strip()]
        if questions:
            return questions[:count]
    except Exception as error:
        print(f"Question generation fallback: {error}")
    questions = fallback_questions(role, kind, count)
    while len(questions) < count:
        questions.append(f"What would you do to improve your skills as a {role}?")
    return questions[:count]

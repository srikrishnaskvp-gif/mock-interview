import sqlite3
from contextlib import contextmanager
from app.config import DATABASE_PATH
SCHEMA = '''
CREATE TABLE IF NOT EXISTS interviews (
 id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, interview_type TEXT NOT NULL,
 difficulty TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'in_progress',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS questions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, interview_id INTEGER NOT NULL REFERENCES interviews(id) ON DELETE CASCADE,
 question_text TEXT NOT NULL, question_type TEXT NOT NULL DEFAULT 'general', position INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS answers (
 id INTEGER PRIMARY KEY AUTOINCREMENT, interview_id INTEGER NOT NULL REFERENCES interviews(id) ON DELETE CASCADE,
 question_id INTEGER NOT NULL REFERENCES questions(id) ON DELETE CASCADE, answer_text TEXT NOT NULL,
 transcript TEXT, score REAL, feedback TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);'''
@contextmanager
def connection():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()
def init_db():
    with connection() as conn:
        conn.executescript(SCHEMA)

from pydantic import BaseModel, Field
from typing import Literal
class InterviewCreate(BaseModel):
 role: str = Field(min_length=1, max_length=120)
 interview_type: Literal["technical","hr","general"] = "general"
 difficulty: Literal["beginner","intermediate","advanced"] = "intermediate"
 question_count: int = Field(default=5, ge=1, le=15)
class AnswerSubmit(BaseModel):
 question_id: int
 answer_text: str = Field(min_length=1, max_length=20000)
class EvaluateRequest(BaseModel):
 question: str = Field(min_length=1, max_length=5000)
 answer: str = Field(min_length=1, max_length=20000)
 role: str = "General candidate"
class ResumeRequest(BaseModel):
 resume_text: str = Field(min_length=1, max_length=30000)
 target_role: str = "General role"

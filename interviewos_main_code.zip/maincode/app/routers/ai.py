import json
from fastapi import APIRouter, HTTPException, UploadFile, File
from app.db import connection
from app.schemas import EvaluateRequest, ResumeRequest
from app.services.ai_service import chat
from app.services.transcription import transcribe_audio
router=APIRouter(tags=["AI"])
@router.post("/transcribe")
async def transcribe(file:UploadFile=File(...)):
    raw=await file.read()
    if not raw: raise HTTPException(400,"Audio file is empty")
    try: return {"transcript":await transcribe_audio(file.filename or "answer_audio",raw)}
    except Exception as e: raise HTTPException(502,f"Transcription failed: {e}") from e
@router.post("/interviews/{iid}/questions/{qid}/audio-answer")
async def audio_answer(iid:int,qid:int,file:UploadFile=File(...)):
    raw=await file.read()
    if not raw: raise HTTPException(400,"Audio file is empty")
    try: transcript=await transcribe_audio(file.filename or "answer_audio",raw)
    except Exception as e: raise HTTPException(502,f"Transcription failed: {e}") from e
    with connection() as c:
        if not c.execute("SELECT id FROM questions WHERE id=? AND interview_id=?",(qid,iid)).fetchone(): raise HTTPException(404,"Question not found in this interview")
        cur=c.execute("INSERT INTO answers(interview_id,question_id,answer_text,transcript) VALUES(?,?,?,?)",(iid,qid,transcript,transcript))
    return {"answer_id":cur.lastrowid,"transcript":transcript,"status":"transcribed_and_saved"}
@router.post("/evaluate")
async def evaluate(body:EvaluateRequest):
    prompt=f'Assess this answer for role {body.role}. Question: {body.question}\nAnswer: {body.answer}\nReturn JSON keys: score (0-100), relevance (0-100), clarity (0-100), strengths (array), improvements (array), feedback (string), suggested_answer_structure (array). Be constructive; do not infer honesty or confidence from appearance.'
    try: return json.loads(await chat("You are a fair interview coach. Return valid JSON.",prompt,True))
    except Exception as e: raise HTTPException(502,f"Evaluation failed: {e}") from e
@router.post("/resume/analyze")
async def resume(body:ResumeRequest):
    prompt=f'Review this resume for {body.target_role}:\n{body.resume_text}\nReturn JSON keys: summary, relevant_skills, gaps, improvements, project_suggestions, role_fit_notes. Do not invent qualifications.'
    try: return json.loads(await chat("You are a practical resume reviewer. Return valid JSON.",prompt,True))
    except Exception as e: raise HTTPException(502,f"Resume analysis failed: {e}") from e

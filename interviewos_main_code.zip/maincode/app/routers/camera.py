from fastapi import APIRouter, UploadFile, File, HTTPException
import cv2, numpy as np
router=APIRouter(prefix="/camera",tags=["Camera"])
@router.post("/analyze-frame")
async def analyze_frame(file:UploadFile=File(...)):
    raw=await file.read()
    if not raw: raise HTTPException(400,"Image file is empty")
    frame=cv2.imdecode(np.frombuffer(raw,dtype=np.uint8),cv2.IMREAD_COLOR)
    if frame is None: raise HTTPException(400,"Invalid image")
    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    detector=cv2.CascadeClassifier(cv2.data.haarcascades+"haarcascade_frontalface_default.xml")
    faces=detector.detectMultiScale(gray,1.1,5,minSize=(40,40))
    brightness=round(float(np.mean(gray)),1)
    sharpness=round(float(cv2.Laplacian(gray,cv2.CV_64F).var()),1)
    return {"frame_width":int(frame.shape[1]),"frame_height":int(frame.shape[0]),"face_count":int(len(faces)),"face_visible":bool(len(faces)>0),"brightness_mean":brightness,"lighting":"low" if brightness<45 else "high" if brightness>215 else "acceptable","sharpness_score":sharpness,"blur_estimate":"possibly_blurry" if sharpness<45 else "acceptable","notice":"Approximate visual signals only; not evidence of cheating or a reliable measure of confidence."}

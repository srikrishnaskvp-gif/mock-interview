from fastapi import APIRouter, HTTPException
from app.db import connection
from app.schemas import InterviewCreate, AnswerSubmit
from app.services.ai_service import generate_questions
router=APIRouter(prefix="/interviews",tags=["Interviews"])
@router.get("")
def list_interviews():
    with connection() as c:
        rows = c.execute("SELECT * FROM interviews ORDER BY id DESC").fetchall()
    return [dict(row) for row in rows]

@router.post("")
async def create_interview(body: InterviewCreate):
    qs=await generate_questions(body.role,body.interview_type,body.difficulty,body.question_count)
    with connection() as c:
        cur=c.execute("INSERT INTO interviews(role,interview_type,difficulty) VALUES(?,?,?)",(body.role,body.interview_type,body.difficulty))
        iid=cur.lastrowid
        for i,q in enumerate(qs,1):
            c.execute("INSERT INTO questions(interview_id,question_text,question_type,position) VALUES(?,?,?,?)",(iid,q,body.interview_type,i))
    return get_interview(iid)
@router.get("/{iid}")
def get_interview(iid:int):
    with connection() as c:
        row=c.execute("SELECT * FROM interviews WHERE id=?",(iid,)).fetchone()
        if not row: raise HTTPException(404,"Interview not found")
        qs=c.execute("SELECT id,question_text,question_type,position FROM questions WHERE interview_id=? ORDER BY position",(iid,)).fetchall()
    return {**dict(row),"questions":[dict(q) for q in qs]}
@router.post("/{iid}/answers")
def save_answer(iid:int, body:AnswerSubmit):
    with connection() as c:
        if not c.execute("SELECT id FROM interviews WHERE id=?",(iid,)).fetchone(): raise HTTPException(404,"Interview not found")
        if not c.execute("SELECT id FROM questions WHERE id=? AND interview_id=?",(body.question_id,iid)).fetchone(): raise HTTPException(404,"Question not found in this interview")
        cur=c.execute("INSERT INTO answers(interview_id,question_id,answer_text) VALUES(?,?,?)",(iid,body.question_id,body.answer_text))
    return {"answer_id":cur.lastrowid,"status":"saved"}
@router.get("/{iid}/report")
def report(iid:int):
    with connection() as c:
        interview=c.execute("SELECT * FROM interviews WHERE id=?",(iid,)).fetchone()
        if not interview: raise HTTPException(404,"Interview not found")
        answers=c.execute("SELECT q.question_text,a.answer_text,a.transcript,a.score,a.feedback,a.created_at FROM answers a JOIN questions q ON q.id=a.question_id WHERE a.interview_id=? ORDER BY a.id",(iid,)).fetchall()
    return {"interview":dict(interview),"answers":[dict(a) for a in answers]}

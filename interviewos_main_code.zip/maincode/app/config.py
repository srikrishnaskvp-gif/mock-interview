import os
from dotenv import load_dotenv
load_dotenv()
DATABASE_PATH = os.getenv("DATABASE_PATH", "interview_app.db")
XAI_API_KEY = os.getenv("XAI_API_KEY", "").strip()
XAI_BASE_URL = os.getenv("XAI_BASE_URL", "https://api.x.ai/v1").rstrip("/")
XAI_CHAT_MODEL = os.getenv("XAI_CHAT_MODEL", "grok-3-mini")
XAI_TRANSCRIPTION_MODEL = os.getenv("XAI_TRANSCRIPTION_MODEL", "grok-2-audio")

import { useEffect, useState } from 'react';
import { Activity, ArrowLeft, ArrowRight, BarChart3, BrainCircuit, BriefcaseBusiness, CheckCircle2, ChevronRight, Clock3, FileText, History, LayoutDashboard, LoaderCircle, MessageSquareText, Mic, Play, Plus, Send, Sparkles, Target, Upload, UserRound, WandSparkles } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000';
const nav = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'interview', label: 'Mock interview', icon: MessageSquareText },
  { id: 'resume', label: 'Resume insights', icon: FileText },
  { id: 'history', label: 'Interview history', icon: History },
];

async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, { ...options, headers: { 'Content-Type': 'application/json', ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.detail || `Request failed (${response.status})`);
  return data;
}

export default function App() {
  const [page, setPage] = useState('dashboard');
  const [role, setRole] = useState('Python Backend Developer');
  const [kind, setKind] = useState('technical');
  const [difficulty, setDifficulty] = useState('beginner');
  const [count, setCount] = useState(5);
  const [interview, setInterview] = useState(null);
  const [index, setIndex] = useState(0);
  const [answer, setAnswer] = useState('');
  const [answers, setAnswers] = useState([]);
  const [evaluation, setEvaluation] = useState(null);
  const [history, setHistory] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [resumeText, setResumeText] = useState('');
  const [resumeRole, setResumeRole] = useState('Python Backend Developer');
  const [resumeResult, setResumeResult] = useState(null);

  async function loadHistory() {
    try {
      const data = await request('/api/interviews');
      setHistory(Array.isArray(data) ? data : data.interviews || []);
    } catch { /* history endpoint may not exist in an older backend */ }
  }
  useEffect(() => { loadHistory(); }, []);

  async function startInterview(e) {
    e?.preventDefault(); setBusy(true); setError(''); setEvaluation(null); setAnswers([]); setIndex(0); setAnswer('');
    try {
      const data = await request('/api/interviews', { method: 'POST', body: JSON.stringify({ role, interview_type: kind, difficulty, question_count: Number(count) }) });
      setInterview(data); setPage('live'); await loadHistory();
    } catch (err) { setError(`${err.message}. Check that FastAPI and Ollama are running.`); }
    finally { setBusy(false); }
  }

  async function submitAnswer(e) {
    e?.preventDefault();
    if (!interview || !answer.trim()) return;
    const question = interview.questions[index]; setBusy(true); setError('');
    try {
      await request(`/api/interviews/${interview.id}/answers`, { method: 'POST', body: JSON.stringify({ question_id: question.id, answer_text: answer.trim() }) });
      let result;
      try { result = await request('/api/evaluate', { method: 'POST', body: JSON.stringify({ role: interview.role, question: question.question_text, answer: answer.trim() }) }); }
      catch (err) { result = { feedback: `Answer saved. Evaluation unavailable: ${err.message}`, score: null, strengths: [], improvements: [] }; }
      const newAnswer = { question: question.question_text, answer: answer.trim(), evaluation: result };
      const nextAnswers = [...answers, newAnswer]; setAnswers(nextAnswers); setEvaluation(result); setAnswer('');
      if (index + 1 >= interview.questions.length) { setPage('results'); await loadHistory(); }
      else setIndex(index + 1);
    } catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }

  async function analyzeResume(e) {
    e.preventDefault(); setBusy(true); setError(''); setResumeResult(null);
    try { setResumeResult(await request('/api/resume/analyze', { method: 'POST', body: JSON.stringify({ resume_text: resumeText, target_role: resumeRole }) })); }
    catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }

  const latestScore = answers.length ? Math.round(answers.reduce((sum, a) => sum + (Number(a.evaluation?.score) || 0), 0) / answers.length) : null;
  const currentQuestion = interview?.questions?.[index];

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><BrainCircuit size={22}/></div><div><b>InterviewOS</b><small>AI CAREER COACH</small></div></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>{nav.map(item => { const Icon = item.icon; return <button key={item.id} className={`nav-item ${page === item.id || (page === 'live' && item.id === 'interview') || (page === 'results' && item.id === 'interview') ? 'active' : ''}`} onClick={() => { setPage(item.id); setError(''); }}><Icon size={18}/><span>{item.label}</span>{item.id === 'interview' && <ChevronRight size={15} className="nav-chevron"/>}</button>; })}</nav>
      <div className="sidebar-bottom"><div className="plan-card"><div className="plan-icon"><Sparkles size={17}/></div><b>Your next breakthrough</b><p>Practice consistently and turn feedback into progress.</p><button onClick={() => setPage('interview')}>Start practicing <ArrowRight size={14}/></button></div><div className="profile"><div className="avatar"><UserRound size={18}/></div><div><b>Candidate</b><small>Interview prep</small></div><span className="profile-dot"/></div></div>
    </aside>
    <main className="main-area">
      <header className="topbar"><div className="breadcrumb">Workspace <ChevronRight size={14}/> <b>{page === 'live' ? 'Live interview' : page === 'results' ? 'Interview report' : nav.find(n => n.id === page)?.label || 'Dashboard'}</b></div><div className="topbar-right"><span className="status-pill"><span/> Local AI ready when Ollama is running</span><div className="mini-avatar">C</div></div></header>
      <div className="content">
        {error && <div className="error-banner"><b>Something needs attention:</b> {error}<button onClick={() => setError('')}>Dismiss</button></div>}
        {page === 'dashboard' && <>
          <section className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> YOUR PERSONAL INTERVIEW COACH</div><h1>Build confidence.<br/><span>One answer at a time.</span></h1><p className="subheading">Practice with AI, discover your strengths, and make every interview count.</p><div className="welcome-actions"><button className="primary-btn" onClick={() => setPage('interview')}><Plus size={18}/> Start a mock interview</button><button className="secondary-btn" onClick={() => setPage('history')}>View history <ArrowRight size={16}/></button></div></div><div className="hero-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="hero-core"><BrainCircuit size={56}/></div><div className="float-chip chip-a"><Target size={15}/> Role-focused</div><div className="float-chip chip-b"><Activity size={15}/> Smart feedback</div><div className="spark-dot dot-a"/><div className="spark-dot dot-b"/></div></section>
          <section className="stat-grid"><Stat icon={History} label="Interviews started" value={history.length} note="Saved in your workspace"/><Stat icon={BarChart3} label="Latest average score" value={latestScore == null ? '—' : `${latestScore}%`} note="From this session"/><Stat icon={Target} label="Practice focus" value="Your role" note="Personalized questions"/><Stat icon={Clock3} label="Session length" value={`${count} Qs`} note="Adjust before starting"/></section>
          <section className="dashboard-grid"><div className="panel quick-panel"><div className="panel-heading"><div><span className="section-kicker">GET STARTED</span><h2>Choose your next move</h2></div><WandSparkles size={20}/></div><div className="quick-cards"><Quick icon={MessageSquareText} title="Mock interview" desc="Role-specific questions with feedback." onClick={() => setPage('interview')}/><Quick icon={FileText} title="Resume insights" desc="Find gaps and improve your resume." onClick={() => setPage('resume')}/></div></div><div className="panel"><div className="panel-heading"><div><span className="section-kicker">RECENT ACTIVITY</span><h2>Interview history</h2></div><button className="text-button" onClick={() => setPage('history')}>See all <ArrowRight size={14}/></button></div>{history.length ? <div className="history-list">{history.slice(0,4).map(h => <HistoryRow key={h.id} item={h} onClick={async () => { try { const d = await request(`/api/interviews/${h.id}`); setInterview(d); setPage('live'); setIndex(0); } catch (err) { setError(err.message); } }}/>)}</div> : <div className="empty-state"><div className="empty-icon"><History size={21}/></div><b>Your journey starts here</b><p>Your saved interviews will appear here.</p><button className="text-button" onClick={() => setPage('interview')}>Create your first interview <ArrowRight size={14}/></button></div>}</div></section>
        </>}
        {page === 'interview' && <section className="form-layout"><div className="page-heading"><div className="eyebrow"><Sparkles size={14}/> PRACTICE STUDIO</div><h1>Set up your interview</h1><p>Customize a session that matches your goals. Your AI coach will prepare the questions.</p></div><form className="panel setup-form" onSubmit={startInterview}><div className="form-title"><div className="form-title-icon"><BriefcaseBusiness size={20}/></div><div><h2>Interview preferences</h2><p>Choose the experience you want to practice.</p></div></div><label>Target role<input value={role} onChange={e => setRole(e.target.value)} required placeholder="e.g. Python Backend Developer"/></label><div className="field-row"><label>Interview type<select value={kind} onChange={e => setKind(e.target.value)}><option value="technical">Technical</option><option value="hr">HR / Behavioral</option><option value="general">General</option></select></label><label>Difficulty<select value={difficulty} onChange={e => setDifficulty(e.target.value)}><option value="beginner">Beginner</option><option value="intermediate">Intermediate</option><option value="advanced">Advanced</option></select></label></div><label>Number of questions <div className="range-line"><input type="range" min="1" max="10" value={count} onChange={e => setCount(e.target.value)}/><span>{count} questions</span></div></label><div className="info-note"><BrainCircuit size={17}/><span>Questions are generated by your local AI model when Ollama is available. Fallback questions are used if AI is unavailable.</span></div><button className="primary-btn full-btn" disabled={busy || !role.trim()}>{busy ? <><LoaderCircle className="spin" size={17}/> Preparing interview…</> : <><Play size={17} fill="currentColor"/> Generate questions and start</>}</button></form></section>}
        {page === 'live' && interview && currentQuestion && <section className="interview-layout"><div className="page-heading compact"><button className="back-button" onClick={() => setPage('interview')}><ArrowLeft size={15}/> Interview setup</button><div className="eyebrow"><span className="live-dot"/> LIVE PRACTICE SESSION</div><h1>{interview.role}</h1><p>{interview.interview_type} interview <span className="bullet">•</span> {interview.difficulty}</p></div><div className="progress-wrap"><div><span>QUESTION {index + 1} <span className="muted">OF {interview.questions.length}</span></span><b>{Math.round((index / interview.questions.length) * 100)}% complete</b></div><div className="progress-track"><div style={{ width: `${(index / interview.questions.length) * 100}%` }}/></div></div><div className="panel question-panel"><div className="question-top"><span className="question-badge">QUESTION {String(index + 1).padStart(2, '0')}</span><span className="difficulty-badge">{interview.difficulty}</span></div><h2>{currentQuestion.question_text}</h2><p className="question-tip"><Sparkles size={15}/> Tip: Explain your reasoning and include an example when possible.</p><form onSubmit={submitAnswer}><label>Your answer<textarea rows="8" value={answer} onChange={e => setAnswer(e.target.value)} placeholder="Take a moment to structure your thoughts, then write your answer…" required/></label><div className="answer-footer"><span>{answer.length} characters</span><button className="primary-btn" disabled={busy || !answer.trim()}>{busy ? <><LoaderCircle size={17} className="spin"/> Evaluating…</> : <>{index === interview.questions.length - 1 ? 'Finish interview' : 'Submit & next'} <Send size={16}/></>}</button></div></form></div><div className="session-note"><CheckCircle2 size={16}/> Your answers are saved to the backend before evaluation.</div></section>}
        {page === 'results' && <section className="results-layout"><div className="page-heading"><div className="eyebrow"><Sparkles size={14}/> SESSION COMPLETE</div><h1>Your interview report</h1><p>Review your answers and turn feedback into your next practice plan.</p></div><div className="score-banner"><div className="score-circle"><b>{latestScore == null ? '—' : latestScore}</b><span>/ 100</span></div><div><span className="section-kicker">YOUR SESSION SUMMARY</span><h2>{latestScore == null ? 'Interview completed' : latestScore >= 80 ? 'Strong work — keep building' : latestScore >= 60 ? 'Good progress to build on' : 'A useful first step'}</h2><p>{answers.length} answers reviewed for {interview?.role}. Scores are AI-generated guidance, not a definitive measure of ability.</p></div><button className="secondary-btn" onClick={() => { setPage('interview'); setInterview(null); }}>Practice again <ArrowRight size={16}/></button></div><div className="review-list">{answers.map((a,i) => <div className="panel review-card" key={i}><div className="review-head"><span>QUESTION {String(i+1).padStart(2,'0')}</span>{a.evaluation?.score != null && <b>{a.evaluation.score}/100</b>}</div><h3>{a.question}</h3><div className="your-answer"><span>Your answer</span><p>{a.answer}</p></div><div className="feedback-grid"><Feedback title="Strengths" items={a.evaluation?.strengths}/><Feedback title="Improvements" items={a.evaluation?.improvements}/></div><div className="feedback-text"><b>Coach feedback</b><p>{a.evaluation?.feedback || 'No additional feedback available.'}</p></div>{a.evaluation?.suggested_answer_structure && <div className="feedback-text"><b>Suggested answer structure</b><p>{Array.isArray(a.evaluation.suggested_answer_structure) ? a.evaluation.suggested_answer_structure.join(' · ') : a.evaluation.suggested_answer_structure}</p></div>}</div>)}</div><button className="primary-btn" onClick={() => setPage('dashboard')}>Back to dashboard <ArrowRight size={16}/></button></section>}
        {page === 'resume' && <section className="form-layout"><div className="page-heading"><div className="eyebrow"><FileText size={14}/> RESUME INTELLIGENCE</div><h1>See your resume differently</h1><p>Get role-specific feedback, skill gaps, and practical next steps from your local AI coach.</p></div><form className="panel setup-form" onSubmit={analyzeResume}><div className="form-title"><div className="form-title-icon"><Upload size={20}/></div><div><h2>Analyze resume text</h2><p>Paste the text extracted from your resume.</p></div></div><label>Target role<input value={resumeRole} onChange={e => setResumeRole(e.target.value)} required/></label><label>Resume text<textarea rows="10" value={resumeText} onChange={e => setResumeText(e.target.value)} required placeholder="Paste your resume summary, skills, experience, and projects here…"/></label><div className="info-note"><FileText size={17}/><span>This version accepts pasted text. PDF/DOCX file extraction is not included in this minimal build.</span></div><button className="primary-btn full-btn" disabled={busy || !resumeText.trim()}>{busy ? <><LoaderCircle size={17} className="spin"/> Analyzing…</> : <><Sparkles size={17}/> Analyze resume</>}</button></form>{resumeResult && <div className="panel resume-results"><span className="section-kicker">ANALYSIS RESULTS</span><h2>Resume insights</h2><p>{resumeResult.summary}</p><ResultList title="Relevant skills" items={resumeResult.relevant_skills}/><ResultList title="Potential gaps" items={resumeResult.gaps}/><ResultList title="Improvements" items={resumeResult.improvements}/><ResultList title="Project suggestions" items={resumeResult.project_suggestions}/><ResultList title="Role fit" items={resumeResult.role_fit_notes}/></div>}</section>}
        {page === 'history' && <section className="history-page"><div className="page-heading"><div className="eyebrow"><History size={14}/> YOUR PROGRESS</div><h1>Interview history</h1><p>Return to a previous session or start a new round of practice.</p></div><div className="panel"><div className="panel-heading"><div><span className="section-kicker">SAVED SESSIONS</span><h2>{history.length} interview{history.length === 1 ? '' : 's'}</h2></div><button className="primary-btn small-btn" onClick={() => setPage('interview')}><Plus size={15}/> New interview</button></div>{history.length ? <div className="history-list large-list">{history.map(h => <HistoryRow key={h.id} item={h} onClick={async () => { try { const d = await request(`/api/interviews/${h.id}`); setInterview(d); setIndex(0); setPage('live'); } catch (err) { setError(err.message); } }}/>)}</div> : <div className="empty-state"><div className="empty-icon"><History size={21}/></div><b>No saved interviews yet</b><p>Complete your first session to see it here.</p><button className="primary-btn" onClick={() => setPage('interview')}>Start an interview <ArrowRight size={16}/></button></div>}</div></section>}
      </div>
      <footer className="footer"><span>InterviewOS <span className="footer-dot">•</span> Built for better practice</span><span>AI feedback is guidance, not a hiring decision.</span></footer>
    </main>
  </div>;
}

function Stat({ icon: Icon, label, value, note }) { return <div className="stat-card"><div className="stat-top"><span>{label}</span><div><Icon size={17}/></div></div><b className="stat-value">{value}</b><small>{note}</small></div>; }
function Quick({ icon: Icon, title, desc, onClick }) { return <button className="quick-card" onClick={onClick}><div className="quick-icon"><Icon size={19}/></div><div><b>{title}</b><p>{desc}</p></div><ChevronRight size={17}/></button>; }
function HistoryRow({ item, onClick }) { return <button className="history-row" onClick={onClick}><div className="history-icon"><BriefcaseBusiness size={17}/></div><div className="history-main"><b>{item.role || 'Interview session'}</b><small>{item.interview_type || 'general'} <span>·</span> {item.difficulty || 'intermediate'}</small></div><span className={`history-status ${item.status === 'completed' ? 'done' : ''}`}>{item.status || 'in progress'}</span><ChevronRight size={17}/></button>; }
function Feedback({ title, items }) { const list = Array.isArray(items) ? items : items ? [items] : []; return <div className="feedback-box"><b>{title}</b>{list.length ? <ul>{list.map((item,i)=><li key={i}>{item}</li>)}</ul> : <p>No items returned.</p>}</div>; }
function ResultList({ title, items }) { const list = Array.isArray(items) ? items : items ? [items] : []; return <div className="result-list"><h3>{title}</h3>{list.length ? <ul>{list.map((x,i)=><li key={i}>{typeof x === 'string' ? x : JSON.stringify(x)}</li>)}</ul> : <p>Not provided.</p>}</div>; }
